## 🍜 About me

🌿 Streamujem každý deň 8+ hodín študovania štýlom "Study with me". Učím sa tam všetko od Programovania po Psychológiu. Všetky postupy ktoré používam na učenie dokumentujem a zdieľam do dokumentov, ktoré sú prístupné pre [Ko-fi podporovateľov](https://ko-fi.com/patrikzudel/tiers) na  našom Discorde. 

🌿 YŪGEN, som založil s cieľom nasýtiť moju zvedavosť a snáď možno aj motivovať ľudí, aby si našli kúsok času a zlepšovali sa v čomkoľvek, čo ich zaujíma. 

### Podporte ma na [Ko-fi](https://ko-fi.com/patrikzudel/tiers) a získajte prístup k dokumentom v ktorých popisujem moje postupy pri učení. Ďakujem!

## 👨‍🎓 Education
- Bachelors in Computer Science @ [STU FEI](https://www.fei.stuba.sk/) 

## 🥇 Achievements
- Student of the Year 2020 Award - [Slovak University of Technology](https://www.stuba.sk/sk/diani-na-stu/prehlad-aktualit/rektor-stu-miroslav-fikar-udelil-ocenenia-student-roka-2020.html?page_id=13848)
- Ranked #1 Student by grades at Computer Science Year 2019/2020 @ [STU FEI](https://www.fei.stuba.sk/)

## 🖥️ Links
-  [Twitter](https://twitter.com/PatrikZero)
-  [Github](https://github.com/patrikzudel)
-  [Instagram](https://www.instagram.com/patrikzero/)
- [Discord](https://discord.com/invite/HqJjGWX)

-  [Support me!](https://ko-fi.com/patrikzudel/tiers)


💻❤🍲 by [Patrik Žúdel](https://twitter.com/PatrikZero)