## 🍜 About me

Hey I am Patrik Žúdel, also known as Zero. 

I am a professional esports player and a computer science student in my third year. I really love ramen.

## 👨‍🎓 Education

- Bachelors in Computer Science @ [STU FEI](https://www.fei.stuba.sk/) 

## 🥇 Achievements

- Student of the Year 2020 Award - [Slovak University of Technology](https://www.stuba.sk/sk/diani-na-stu/prehlad-aktualit/rektor-stu-miroslav-fikar-udelil-ocenenia-student-roka-2020.html?page_id=13848)
- Ranked #1 Student by grades at Computer Science Year 2019/2020 @ [STU FEI](https://www.fei.stuba.sk/)

## 🖥️ Links
-  [Twitter](https://twitter.com/PatrikZero)
-  [Github](https://github.com/patrikzudel)
-  [Instagram](https://www.instagram.com/patrikzero/)

-  [Support me!](https://www.buymeacoffee.com/patrikzero)


💻❤🍲 by [Patrik Žúdel](https://twitter.com/PatrikZero)

<img src="https://visitor-badge.glitch.me/badge?page_id=patrikzudel.patrikzudel&left_color=black&right_color=black" align="right">