---
tag:meta-learning, javascript, node.js, programming
---
### Terminológia
- DOM: HTML obsah stránky.

# Predpoklady
### Základné predpoklady:
- Skúsenosti s programovaním
- Vlastné projekty v iných jazykoch
- Znalosti základov. Schopnosť skonceptualizovať jednoduché projekty v pseudokóde.
- CS50 - Kurz ktorý vás naučí tie najdoležitejšie základy

Nieje potrebné splniť všetky základné predpoklady,  nejaké ale treba určite.

### Javascript predpoklady: 
### [JavaScript Concepts you Need to Know](https://www.youtube.com/watch?v=lkIFF4maKMU)
- Dobrý speedrun pre vela konceptov v JS, užitočné keď som v tom už minulosti robil a potrebujem zopakovanie.

### [All The JavaScript You Need To Know For React](https://www.youtube.com/watch?v=m55PTVUrlnA)
- Toto video pozrieť, a vždy keď hovorí o niečom čo očakáva, že by sme mali vedieť tak treba vygoogliť.
- Napríklad hovorí o exportovaní funkcii. 
	- Google -> "whats exporting function in javascript" a pokúsiť sa tomu porozumieť.
- Hovorí o objects 
	- Google -> "what are objects in javascript" && "how are objects used in javascript" || Alebo sa pozriem do [JS Overview](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Language_Overview#objects) 

### [Javascript Language Overview ](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Language_Overview#objects)
- Dobrý súhrn roznych konceptov v JS.

### [TypeScript in 100 Seconds](https://www.youtube.com/watch?v=zQnBQ4tB3ZA)
- React može používať Typescript, takže treba vedieť čo to vlastne znamená.

# Čo som robil ja
...
...

# Čo odporúčam
...
...

## Staňte sa podporovateľom na Ko-fi pre prístup k
([Link na Ko-fi](https://ko-fi.com/patrikzudel/tiers))
- Kompletnej dokumentácii krokov ktoré som použil na to aby som sa zoznámil s Reactom a získal vedomosti na to aby som sa sním mohol začať hrať.
- Informácie o tom čo som robil, a čo by som urobil inak ak by som sa to učil znova.
- Všetky tieto informácie su priebežne aktualizované popri tom ako sa učím a objavujem nové postupy.