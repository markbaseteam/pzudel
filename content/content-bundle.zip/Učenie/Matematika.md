### Tento dokument je nedokončený.

##### Khan Academy (Angličtina ale sú aj CZ titulky)
Podľa mňa najlepšie mieto na získanie kvalitných základov matematiky. Možete sa tu naučiť naozaj všetko od základnej školy po vysokú. Je to dokonalý priestor pre niekoho znovu-objaviť matematiku a naozaj si knej vytvoriť vzťah.
* https://www.khanacademy.org/math
 **Tu je učivo zoradené v takej postupnosti ako by ste sa to rovno mohli aj učiť, kludne si možete začať na ZŠ Matematike a veľmi rýchlo sa vybudovať vyššie a vyššie.**