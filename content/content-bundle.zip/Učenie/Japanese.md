### Terminológia
- Output: Hovorenie, písanie, tvorenie viet, vyjadrovanie sa
- Input: Počúvanie, porozumenie, čítanie
- Immersion: Koncept toho, že jazyk sa najlepšie naučíš ponorením doň. Tým že neustále sa stretávaš s novými slovami, neustále ho "okolo seba" počúvaš alebo čítaš. Zapadá doňho napr: Pozeranie filmov v danom jazyku, cestovanie do ich krajiny atď.
- Anki: Program na memorizovanie informácii.
- Deck: Sada kartičiek pre Anki. Obsahuje napríklad slová a ich významy.
- Review: Recenzia kartičky ktorú už by ste mali vedieť v Anki.
- Core 2k/6k deck: Sada kartičiek ktorá má 6000 najpoužívanejších slov v Japončine.


## Momentálny stav
### 23.04.2023 sa učím Japončinu 159 dní:
#### Core 2k/6k deck: 1210/6000
#### Jlab's course: 921/2091
#### Hiragana: 46/46
#### Katakana: 46/46

#### Najbližší ciel: JLPT N5

## Intro
Najprv som si spravil dosť obsiahly prieskum toho, aké sú možnosti učenia sa.
Jazyky sa dajú učiť rôznymi spôsobmi, v škole sa ich napríklad učíme cez učebnice a celkom rýchlo sa sústredíme na output. Tento spôsob má svoje výhody aj nevýhody - celkom rýchlo sa naučíme základné vety, ale keďže sa skoro snažíme hovoriť, tak si môžeme vybudovať zlozvyky. Tiež je to v určitom zmysle neefektívne, pretože počúvaním a čítaním si rýchlejšie vybudujeme slovnú zásobu, ktorá je jadrom porozumenia.

Veľa ľudí si myslí, že na to aby si vedel jazyk dobre, musíš aj veľa rozprávať. To ale nie je pravda. Je bežné, že sa ľudia učia nejaký jazyk aj napr. 2 roky bez toho, že by sa pokúsili rozprávať, a len sa sústredia na input. Takí ľudia bežne rozumejú veľmi veľkej časti daného jazyka, len zatiaľ ešte netrénovali output. Keď sa potom o ten output pokúsia, je to pre nich oveľa jednoduchšie, a samozrejme rozprávať z veľkej časti proste dokážu prirodzene. A keď urobia chybu, tak ju oveľa ľahšie spoznajú, kedže už majú za sebou stovky hodín počúvania.

Spôsob, ktorý som si vybral ja je práve taký, ktorý sa sústredí hlavne na budovanie slovnej zásoby a **INPUT**.  

### Základný plán:
- Naučiť sa Hiragana / Katakana
- Učiť sa 10 nových slov každý deň
- Pozerať anime / japonské seriály
- Na gramatiku si raz prečítať [Tae Kim's Guide](https://guidetojapanese.org/learn/) - len aby som mal predstavu ako určité veci fungujú.

#### Poznámka o gramatike:
Venovať príliš veľa času gramatike nie je ideálne, pretože to sú veci, ktorým naozaj porozumieme až cez stovky až tisíce hodín počúvania toho daného jazyka. Je oveľa ľahšie si vybudovať spojitosti zo skúseností s jazykom, ako sa ich proste nadrviť z učebnice.

# Učenie
## 1. Hiragana / Katakana
...
...
...
## Staňte sa podporovateľom na Ko-fi pre prístup k
([Link na Ko-fi](https://ko-fi.com/patrikzudel/tiers))
- Kompletnej dokumentácii krokov, ktoré som používam na učenie abecéd, slovnej zásoby a všetkého iného.
- Informácie a tipy o tom čo špecificky robím a čo by som zmenil ak by som sa to učil znova.

## Dozviete sa tam
- Ako som sa naučil Hiragana / Katakana
- Ako sa učím 6000 najčastejšie používaných slov. (Kanji atď!)
- Aký špeciálny script používam na to aby som si Kanji zapamätal ešte rýchlejšie!
- Ako mám nastavené Anki a aké extensions používam.
- Ako sa učím gramatiku.
- Kde sa dajú nájsť anime, ktoré sú prispôsobene vašej úrovni Japončiny.


---
💻❤🍲 by [Patrik Žúdel](https://twitter.com/PatrikZero)