### Tento dokument je nedokončený.

##### CS50 (Angličtina)
Úžasný kurz od Harvardu ktorý vám dá naozaj kvalitné základy z programovania a zároveň poskytuje dobré nástroje na získanie doležitých intuícii k porozumeniu fungovania počítačov.
* https://www.edx.org/course/introduction-computer-science-harvardx-cs50x
 **(Tu stačí dať Enroll now a zaregistrovať sa na ich stránke. Celá výučba funguje cez ich systém, funguje to normálne ako výučba na VŠ a teda majú zadania aj nástroje na kontrolovanie zadaní atp.)**