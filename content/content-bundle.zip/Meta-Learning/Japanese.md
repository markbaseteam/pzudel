
## Anki

---
💻❤🍲 by [Patrik Žúdel](https://twitter.com/PatrikZero)