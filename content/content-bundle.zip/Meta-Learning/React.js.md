---
tag:meta-learning, javascript, node.js, programming
---

## Prerequisites
- Skusenosti s programovanim
	- Vlastne projekty v inych jazykoch
	- Znalosti zakladov, vediet si predstavit ako postavit jednoduche projekty v pseudokode.
	- [[📖 Vzdelavacie pomocky#CS50 (Angličtina)|CS50]]
	- Bolo by fajn si najprv urobit nejaky jednoduchy projekt kde puzivame Vanilla JS + HTML + CSS. Napr. jednoduchu kalkulacku [+, -, *, /]

### [JavaScript Concepts you Need to Know](https://www.youtube.com/watch?v=lkIFF4maKMU)
- Dobry speedrun pre vela konceptov v JS, dobre ked som v tom minulosti uz robil a potrebujem reminder

### [All The JavaScript You Need To Know For React](https://www.youtube.com/watch?v=m55PTVUrlnA)
- Toto video pozriet, a vzdy ked hovori o niecom co ocakava ze by sme mali vediet tak vygooglim. 
- Napr. hovori o exportovani funkcii. -> Google -> "whats exporting function in javascript" a pokusit sa tomu porozumiet.
	- Hovori o objects -> "what are objects in javascript" && "how are objects used in javascript" || Alebo sa pozriem do [JS Overview](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Language_Overview#objects) 

### [Javascript Language Overview ](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Language_Overview#objects)
- Dobra summary roznych konceptov v JS

### [TypeScript in 100 Seconds](https://www.youtube.com/watch?v=zQnBQ4tB3ZA)
- React pouziva Typescript, takze treba vediet co to vlastne znamena

## Steps I took
1. Naprogramoval som si kalkulacku s co najmenej pomocou internetu s vanilla JS.
2. Spravil kalkulacku podla [tutorialu](https://www.youtube.com/watch?v=j59qQ7YWLxw) s vanilla JS.
3. Znova tu istu kalkulacku pomocou [tutorialu](https://www.youtube.com/watch?v=DgRrrOt0Vr8) cez react.

## STEP 3. ([TUTORIAL!!!!!](https://youtu.be/DgRrrOt0Vr8))
**Tutorial ale nestaci, treba kuknut aj vsetko dole podtymto predtym ako budeme vediet vobec tutorial robit.**
#### Jak VOBEC vyrobit projekt ktory pouziva REACT????
##### Nastudovat si rozdiel medzi static, single page apps a multi-page server-side apps
[Jeden link](https://stackoverflow.com/questions/37868971/difference-between-single-page-application-and-web-application), [dalsi link](https://medium.com/@NeotericEU/single-page-application-vs-multiple-page-application-2591588efe58)

##### Build tools ([videjko](https://www.youtube.com/watch?v=2OTq15A5s0Y&t=85s))
###### Single page app 
```ad-note

Neznamena to ze mozes mat len 1 page, mozes ich mat viac ale robis to cez Router. Multi-page stranky ktore su server-side generuju novy .html subor pre kazdu page. V tomto pripade to skor "fakujeme" cez routing.
```
- Vite
- Create-react-app
###### Static website generator
- Gatsby
###### Server-side (Multi-page)
- Next.js

Spravny general path v 2023 je **Vite -> Typescript -> React**
#### Ako vyrobit projekt cez Vite (najprv treba nainstalovat Node.js)
<iframe title="Vite React Project in 5 Minutes 🔥" src="https://www.youtube.com/embed/vr-I2HIVmTw?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>
# IDZEME KODIT!
##### React hooks
- Zatial mi tie najdolezitejsie hooks pridu ako fancy way of creating variables ktore su neustale updatovane v DOM + k nim assign funkciu ktora ich update
- let [variable_name, setter] = useState(variable);
	- Priklad: let [name, changeName] = useState('Peter');
<iframe title="10 React Hooks Explained // Plus Build your own from Scratch" src="https://www.youtube.com/embed/TNhaISOUy6Q?feature=oembed" height="113" width="200" style="aspect-ratio: 16 / 9; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>
##### Speedrun react
<iframe title="I built the same app 10 times // Which JS Framework is best?" src="https://www.youtube.com/embed/cuHDQhDhvPE?start=261&amp;feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>
##### Dalsie dobre videjko pre hooks
<iframe title="Learn useReducer In 20 Minutes" src="https://www.youtube.com/embed/kK_Wqx3RnHk?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

```ad-hint
Odporucam ten tutorial robit v Typescripte co je ale tazke lebo ten tutorial v nom nerobi, preto editor bude hadzat errory. **Odporucam pozriet [[Typescript calculator example]]** tento kod je viac citatelny kvoli tomu ze su tam types ako v tom originalnom tutoriale. Comu nerozumieme sa treba pytat chatGPT. 
```