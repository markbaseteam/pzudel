### Long chill songs I use for work
- [Snowfall](https://www.youtube.com/watch?v=h8QjGO0g_zM)
- [mac miller - congratulations piano only ( slowed + reverb + rain sounds )](https://www.youtube.com/watch?v=nDB3xPMz8pM) 
- [Hisohkah - School Rooftop (Intro)](https://www.youtube.com/watch?v=lyw9yjcaBkc)

### Stream background sounds
I've written a script that randomly plays comforting background noises during my stream. Also a script that plays soft keyboard sounds when I type on my keyboard. 

---
💻❤🍲 by [Patrik Žúdel](https://twitter.com/PatrikZero)