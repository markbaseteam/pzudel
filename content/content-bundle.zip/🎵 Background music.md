### Dlhé relaxujúce pesničky ktoré počúvam pri práci / učení
- [Snowfall](https://www.youtube.com/watch?v=h8QjGO0g_zM)
- [mac miller - congratulations piano only ( slowed + reverb + rain sounds )](https://www.youtube.com/watch?v=nDB3xPMz8pM) 
- [Hisohkah - School Rooftop (Intro)](https://www.youtube.com/watch?v=lyw9yjcaBkc)

### Zvuky prírody v pozadí
- [Mynoise.net](https://mynoise.net/)
	- Oblúbené
		- [Healing water](https://mynoise.net/NoiseMachines/healingWaterSoundscapeGenerator.php)
		- [Japanese garden](https://mynoise.net/NoiseMachines/japaneseGardenSoundscapeGenerator.php)
		- [Singing bowls](https://mynoise.net/NoiseMachines/singingBowlsDroneGenerator.php)
		- [Japanese Oase](https://mynoise.net/NoiseMachines/japaneseSuikinkutsuSoundscapeGenerator.php)

### Zvuky z pozadia streamu
Napísal som si skripty ktoré náhodne hrajú príjemne zvuky do pozadia mojho streamu. Tiež ďalší script ktorý simuluje zvuky klávesnice keď píšem, pretože naozaj mám mikrofón vypnutý.

## English
### Long chill songs I use for work
- [Snowfall](https://www.youtube.com/watch?v=h8QjGO0g_zM)
- [mac miller - congratulations piano only ( slowed + reverb + rain sounds )](https://www.youtube.com/watch?v=nDB3xPMz8pM) 
- [Hisohkah - School Rooftop (Intro)](https://www.youtube.com/watch?v=lyw9yjcaBkc)

### Stream background sounds
I've written a script that randomly plays comforting background noises during my stream. Also a script that plays soft keyboard sounds when I type on my keyboard. 

---
💻❤🍲 by [Patrik Žúdel](https://twitter.com/PatrikZero)