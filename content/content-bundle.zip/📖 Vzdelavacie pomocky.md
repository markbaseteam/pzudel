## 💻 Programovanie
##### CS50 (Angličtina)
Úžasný kurz od Harvardu ktorý vám dá naozaj kvalitné základy z programovania a zároveň poskytuje dobré nástroje na získanie doležitých intuícii k porozumeniu fungovania počítačov.
* https://www.edx.org/course/introduction-computer-science-harvardx-cs50x
 **(Tu stačí dať Enroll now a zaregistrovať sa na ich stránke. Celá výučba funguje cez ich systém, funguje to normálne ako výučba na VŠ a teda majú zadania aj nástroje na kontrolovanie zadaní atp.)**

## 📘 Matematika
##### Khan Academy (Angličtina ale sú aj CZ titulky)
Podľa mňa najlepšie mieto na získanie kvalitných základov matematiky. Možete sa tu naučiť naozaj všetko od základnej školy po vysokú. Je to dokonalý priestor pre niekoho znovu-objaviť matematiku a naozaj si knej vytvoriť vzťah.
* https://www.khanacademy.org/math
 **Tu je učivo zoradené v takej postupnosti ako by ste sa to rovno mohli aj učiť, kludne si možete začať na ZŠ Matematike a veľmi rýchlo sa vybudovať vyššie a vyššie.**

---
💻❤🍲 by [Patrik Žúdel](https://twitter.com/PatrikZero)